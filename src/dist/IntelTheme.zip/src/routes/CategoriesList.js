import Layout from '../components/Layout'
import '../styles/_theme.scss'
import './CategoriesList.scss'

const CategoriesList = (props) => {
    return (
      <Layout {...props} className="CategoriesList">
        <div className="policy_page">
          <div className="container-fluid">
              <h2 id="cat_header">
                  Categories Classes
              </h2>
          </div>
        </div>        

      </Layout>
    )
}
  
export default CategoriesList